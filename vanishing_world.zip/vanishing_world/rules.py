
import random
from collections import deque

# ----------------------------------------
# BOARD SETTINGS
# ----------------------------------------

ROWS = 5
COLS = 5

START_PLAYER = (0, 0)

START_CRYSTALS = frozenset([
    (0, 4),
    (2, 2),
    (4, 1)
])

EXIT_TILE = (4, 4)

# Use a mutable set so other modules importing WALLS
# can see changes when a new level is generated.
WALLS = set()

LEVEL_NUMBER = 1
CRYSTAL_COUNT = 3


# ----------------------------------------
# MOVEMENT DIRECTIONS
# ----------------------------------------

DIRECTIONS = {
    "UP": (-1, 0),
    "DOWN": (1, 0),
    "LEFT": (0, -1),
    "RIGHT": (0, 1)
}


# ----------------------------------------
# GET CURRENT LEVEL INFORMATION
# ----------------------------------------

def get_exit_tile():
    return EXIT_TILE


def get_start_crystals():
    return START_CRYSTALS


def get_level_number():
    return LEVEL_NUMBER


# ----------------------------------------
# CREATE INITIAL GAME STATE
# ----------------------------------------

def create_initial_state():
    # State:
    # (player, vanished_tiles, crystals, status)

    return (
        START_PLAYER,
        frozenset(),
        START_CRYSTALS,
        "playing"
    )


# ----------------------------------------
# CHECK BOARD BOUNDARIES
# ----------------------------------------

def inside_board(position):
    row, col = position

    return (
        0 <= row < ROWS
        and 0 <= col < COLS
    )


# ----------------------------------------
# GET LEGAL MOVES
# ----------------------------------------

def get_legal_moves(state):
    player, vanished, crystals, status = state

    if status != "playing":
        return []

    legal_moves = []

    for direction, change in DIRECTIONS.items():
        row_change, col_change = change

        new_position = (
            player[0] + row_change,
            player[1] + col_change
        )

        if not inside_board(new_position):
            continue

        # Walls block movement.
        if new_position in WALLS:
            continue

        # Vanished tiles cannot be entered again.
        if new_position in vanished:
            continue

        legal_moves.append(direction)

    return legal_moves



def is_human_goal_state(state):
    player, vanished, crystals, status = state
    collected = len(get_start_crystals()) - len(crystals)

    return player == EXIT_TILE and collected >= 1


def is_ai_goal_state(state):
    player, vanished, crystals, status = state

    return player == EXIT_TILE and len(crystals) == 0



# ----------------------------------------
# MOVE PLAYER
# ----------------------------------------

def move_state(state, direction):
    player, vanished, crystals, status = state

    if status != "playing":
        return state

    legal_moves = get_legal_moves(state)

    if direction not in legal_moves:
        return state

    row_change, col_change = DIRECTIONS[direction]

    new_player = (
        player[0] + row_change,
        player[1] + col_change
    )

    new_vanished = set(vanished)
    new_vanished.add(player)
    new_vanished = frozenset(new_vanished)

    new_crystals = set(crystals)

    if new_player in new_crystals:
        new_crystals.remove(new_player)

    new_crystals = frozenset(new_crystals)

    new_status = "playing"

    if new_player == EXIT_TILE:
        if len(new_crystals) == 0:
            new_status = "won"
        else:
            new_status = "lost"

    new_state = (
        new_player,
        new_vanished,
        new_crystals,
        new_status
    )

    if new_status == "playing":
        if not get_legal_moves(new_state):
            new_state = (
                new_player,
                new_vanished,
                new_crystals,
                "lost"
            )

    return new_state


# ----------------------------------------
# CHECK GOAL STATE
# ----------------------------------------


def is_goal_state(state):
    player, vanished, crystals, status = state

    return (
        status == "won"
        and player == EXIT_TILE
        and len(crystals) == 0
    )


# ----------------------------------------
# GENERATE A RANDOM SOLVABLE PATH
# ----------------------------------------

def create_random_path():
    # Generate a path without revisiting tiles.
    # The final position becomes the exit.

    target_length = random.randint(10, 16)

    path = [START_PLAYER]
    visited = {START_PLAYER}

    def extend_path():
        if len(path) == target_length:
            return True

        current = path[-1]
        possible_positions = []

        for row_change, col_change in DIRECTIONS.values():
            next_position = (
                current[0] + row_change,
                current[1] + col_change
            )

            if not inside_board(next_position):
                continue

            if next_position in visited:
                continue

            possible_positions.append(next_position)

        random.shuffle(possible_positions)

        for next_position in possible_positions:
            path.append(next_position)
            visited.add(next_position)

            if extend_path():
                return True

            path.pop()
            visited.remove(next_position)

        return False

    if extend_path():
        return path

    return create_random_path()


# ----------------------------------------
# CHECK WHETHER THE LEVEL CAN BE COMPLETED
# ----------------------------------------

def has_solution():
    initial_state = create_initial_state()

    queue = deque([initial_state])
    visited_states = {initial_state}

    while queue:
        state = queue.popleft()

        if is_goal_state(state):
            return True

        for direction in get_legal_moves(state):
            next_state = move_state(state, direction)

            if next_state is None:
                continue

            if next_state in visited_states:
                continue

            visited_states.add(next_state)

            if next_state[3] == "won":
                return True

            if next_state[3] == "playing":
                queue.append(next_state)

    return False


# ----------------------------------------
# GENERATE RANDOM WALLS
# ----------------------------------------

def generate_walls(path):
    # Walls must not block the guaranteed path.
    path_positions = set(path)

    available_positions = []

    for row in range(ROWS):
        for col in range(COLS):
            position = (row, col)

            if position in path_positions:
                continue

            available_positions.append(position)

    # Generate between 3 and 5 walls.
    wall_count = min(
        random.randint(3, 5),
        len(available_positions)
    )

    return set(random.sample(available_positions, wall_count))


# ----------------------------------------
# GENERATE A NEW LEVEL
# ----------------------------------------

def generate_new_level():
    global START_CRYSTALS
    global EXIT_TILE
    global LEVEL_NUMBER

    while True:
        path = create_random_path()

        # The last position becomes the exit.
        new_exit = path[-1]

        # Place crystals along the generated path.
        crystal_positions = random.sample(
            path[1:-1],
            CRYSTAL_COUNT
        )

        new_crystals = frozenset(crystal_positions)

        # Generate walls outside the guaranteed path.
        new_walls = generate_walls(path)

        # Install the new board.
        START_CRYSTALS = new_crystals
        EXIT_TILE = new_exit

        # Update the existing set instead of replacing it.
        # This keeps imported WALLS references working.
        WALLS.clear()
        WALLS.update(new_walls)

        # Accept only a level with a valid solution.
        if has_solution():
            LEVEL_NUMBER += 1
            return create_initial_state()
