
# test_rules.py

from rules import (
    create_initial_state,
    move_state,
    get_legal_moves,
    is_goal_state
)


def test_initial_state():
    state = create_initial_state()

    assert state[0] == (0, 0)
    assert len(state[1]) == 0
    assert len(state[2]) == 3
    assert state[3] == "playing"

    print("Initial state test passed")


def test_legal_move():
    state = create_initial_state()

    new_state = move_state(state, "RIGHT")

    assert new_state is not None
    assert new_state[0] == (0, 1)
    assert (0, 0) in new_state[1]

    print("Legal movement test passed")


def test_boundary_collision():
    state = create_initial_state()

    # Moving up from the top row is invalid.
    result = move_state(state, "UP")

    assert result is None
    assert state[0] == (0, 0)

    print("Boundary collision test passed")


def test_open_grid_movement():
    state = create_initial_state()

    state = move_state(state, "RIGHT")
    result = move_state(state, "RIGHT")

    assert result is not None
    assert result[0] == (0, 2)

    print("Open grid movement test passed")


def test_vanished_tile():
    state = create_initial_state()

    state = move_state(state, "RIGHT")

    # The starting tile has vanished.
    result = move_state(state, "LEFT")

    assert result is None
    assert state[0] == (0, 1)

    print("Vanished tile test passed")


def test_crystal_collection():
    # Create a valid test state next to a crystal.
    player = (0, 3)
    vanished = frozenset([(0, 0), (0, 1), (0, 2)])
    crystals = frozenset([(0, 4), (2, 2), (4, 1)])

    state = (player, vanished, crystals, "playing")

    new_state = move_state(state, "RIGHT")

    assert new_state is not None
    assert (0, 4) not in new_state[2]
    assert len(new_state[2]) == 2

    print("Crystal collection test passed")


def test_invalid_direction():
    state = create_initial_state()

    result = move_state(state, "JUMP")

    assert result is None
    assert state == create_initial_state()

    print("Invalid direction test passed")


def test_exit_without_all_crystals():
    # Move to the exit while crystals remain uncollected.
    player = (4, 3)
    vanished = frozenset()
    crystals = frozenset([(0, 4), (2, 2), (4, 1)])

    state = (player, vanished, crystals, "playing")
    new_state = move_state(state, "RIGHT")

    assert new_state is not None
    assert new_state[0] == (4, 4)
    assert len(new_state[2]) > 0
    assert new_state[3] != "won"

    print("Exit without all crystals test passed")


def test_no_legal_moves_after_move():
    # After moving down, every neighboring tile will be
    # unavailable because it has vanished or is already vanished.
    player = (0, 1)
    vanished = frozenset([(1, 0), (1, 2), (2, 1)])
    crystals = frozenset([(0, 4), (2, 2), (4, 1)])

    state = (player, vanished, crystals, "playing")
    new_state = move_state(state, "DOWN")

    assert new_state is not None
    assert new_state[0] == (1, 1)
    assert new_state[3] == "lost"
    assert get_legal_moves(new_state) == []

    print("No legal moves test passed")


def test_goal_check():
    state = create_initial_state()

    assert not is_goal_state(state)

    winning_state = (
        (4, 4),
        frozenset(),
        frozenset(),
        "won"
    )

    assert is_goal_state(winning_state)

    print("Goal state test passed")


if __name__ == "__main__":
    test_initial_state()
    test_legal_move()
    test_boundary_collision()
    test_open_grid_movement()
    test_vanished_tile()
    test_crystal_collection()
    test_invalid_direction()
    test_exit_without_all_crystals()
    test_no_legal_moves_after_move()
    test_goal_check()

    print("\nAll rule tests passed!")
