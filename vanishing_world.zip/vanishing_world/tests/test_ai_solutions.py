
# test_ai_solutions.py

from rules import create_initial_state, move_state
from ai_search import (
    bfs_search,
    dfs_search,
    iddfs_search,
    greedy_search,
    a_star_search
)


def validate_solution(solution):

    if solution is None:
        return False

    state = create_initial_state()

    for direction in solution:

        next_state = move_state(state, direction)

        # The move must be legal.
        if next_state is None:
            return False

        # The game must not end in a loss.
        if next_state[3] == "lost":
            return False

        state = next_state

    # The final state must be a win.
    return state[3] == "won"


def test_all_algorithms():

    algorithms = [
        ("BFS", bfs_search),
        ("DFS", dfs_search),
        ("IDDFS", iddfs_search),
        ("Greedy Best-First", greedy_search),
        ("A*", a_star_search)
    ]

    print("\nVANISHING WORLD - SOLUTION VALIDATION")
    print("=" * 55)

    for name, algorithm in algorithms:

        solution, nodes_explored = algorithm()
        valid = validate_solution(solution)

        if solution is None:
            print(f"{name:<20} No solution found")
        elif valid:
            print(
                f"{name:<20} VALID | "
                f"Moves: {len(solution)} | "
                f"Nodes: {nodes_explored}"
            )
        else:
            print(
                f"{name:<20} INVALID | "
                "Returned path does not win the game"
            )

    print("\nValidation completed.")


if __name__ == "__main__":
    test_all_algorithms()
