import sys
from pathlib import Path

# Add the project root directory to Python's import path.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))


import rules

for level in [1, 4, 7, 10, 13]:
    rules.LEVEL_NUMBER = level
    state = rules.generate_new_level(advance_level=False)

    print(
        f"Level: {rules.get_level_number()}, "
        f"Board: {rules.ROWS}x{rules.COLS}, "
        f"Walls: {len(rules.WALLS)}, "
        f"Crystals: {len(rules.get_start_crystals())}, "
        f"Solvable: {rules.has_solution()}"
    )

    assert rules.has_solution()
    assert state[0] == rules.START_PLAYER