import rules

for i in range(5):
    state = rules.generate_new_level()

    print(f"\nLevel: {rules.get_level_number()}")
    print("Start:", state[0])
    print("Crystals:", sorted(state[2]))
    print("Exit:", rules.get_exit_tile())
    print("Solvable:", rules.has_solution())