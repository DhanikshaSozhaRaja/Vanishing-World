from rules import create_initial_state
from ai_search import (
    bfs_search,
    dfs_search,
    iddfs_search,
    greedy_search,
    a_star_search,
)

state = create_initial_state()

algorithms = [
    ("BFS", bfs_search),
    ("DFS", dfs_search),
    ("IDDFS", iddfs_search),
    ("Greedy", greedy_search),
    ("A*", a_star_search),
]

for name, algorithm in algorithms:
    path, nodes = algorithm(start_state=state)

    print(name)
    print("Solution found:", path is not None)
    print("Nodes explored:", nodes)
    print("-" * 25)