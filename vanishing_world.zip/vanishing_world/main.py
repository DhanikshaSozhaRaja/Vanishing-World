import pygame
import time

from compare_algorithms import compare_algorithms

from rules import (
    ROWS,
    COLS,
    WALLS,
    create_initial_state,
    move_state,
    generate_new_level,
    get_exit_tile,
    get_start_crystals,
    get_level_number,
    has_solution,
    is_human_goal_state,
    get_legal_moves,
)

from ai_search import (
    bfs_search,
    dfs_search,
    iddfs_search,
    greedy_search,
    a_star_search,
)


# --------------------------------------------------
# INITIALIZE PYGAME
# --------------------------------------------------

pygame.init()

WIDTH = 900
HEIGHT = 600
TILE_SIZE = 65
BOARD_WIDTH = COLS * TILE_SIZE
BOARD_Y = 125

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Vanishing World - AI Puzzle Game")

clock = pygame.time.Clock()

# Fonts
title_font = pygame.font.Font(None, 42)
font = pygame.font.Font(None, 28)
small_font = pygame.font.Font(None, 21)
tiny_font = pygame.font.Font(None, 19)

# Colors
BACKGROUND = (25, 30, 45)
TILE_COLOR = (65, 75, 95)
GRID_COLOR = (110, 120, 140)
PLAYER_COLOR = (50, 210, 100)
CRYSTAL_COLOR = (60, 200, 255)
EXIT_COLOR = (240, 190, 50)
WALL_COLOR = (15, 18, 28)
VANISHED_COLOR = (35, 38, 48)
WHITE = (245, 245, 245)
RED = (240, 75, 75)
PANEL_COLOR = (36, 43, 61)
PANEL_LINE = (85, 98, 122)
MUTED_TEXT = (180, 190, 207)

# Instruction screen
instructions_open = True
instruction_scroll = 0

CLOSE_BUTTON = pygame.Rect(
    WIDTH // 2 - 80, HEIGHT - 55, 160, 40
)

BUTTON_COLOR = (50, 150, 210)
BUTTON_HOVER_COLOR = (70, 175, 235)

# --------------------------------------------------
# GAME STATE
# --------------------------------------------------

game_state = create_initial_state()
moves = 0
level_has_solution = has_solution()

game_started_at = None
final_game_time = 0.0

# AI playback
ai_moves = []
ai_move_index = 0
ai_playing = False
ai_next_move_time = 0

selected_algorithm = "A*"
ai_was_used = False
ai_nodes_explored = 0
ai_execution_time = 0.0

AI_MOVE_DELAY = 350

# Algorithm comparison screen
show_comparison = False
comparison_results = []

# AI vs Human warning popup
challenge_warning_open = False

WARNING_RECT = pygame.Rect(210, 175, 480, 230)
WARNING_CLOSE_BUTTON = pygame.Rect(370, 330, 160, 42)

# AI vs Human mode
ai_vs_human_mode = False
ai_vs_human_turn = "HUMAN"

human_challenge_moves = 0
ai_challenge_moves = 0

human_challenge_time = 0.0
ai_challenge_time = 0.0

challenge_ai_pending = False
challenge_ai_next_time = 0

# AI vs Human result statistics
challenge_winner = None

human_crystals_collected = 0
ai_crystals_collected = 0

human_turn_time = 0.0
human_turn_started_at = None

challenge_ai_nodes = 0
challenge_ai_searches = 0

# --------------------------------------------------
# RESTART GAME
# --------------------------------------------------
def restart_game():
    global game_state, moves
    global game_started_at, final_game_time
    global ai_moves, ai_move_index, ai_playing
    global ai_next_move_time, selected_algorithm, ai_was_used
    global ai_nodes_explored, ai_execution_time
    global comparison_results

    comparison_results = []

    game_state = create_initial_state()
    moves = 0

    game_started_at = None
    final_game_time = 0.0

    ai_moves = []
    ai_move_index = 0
    ai_playing = False
    ai_next_move_time = 0

    selected_algorithm = "A*"
    ai_was_used = False
    ai_nodes_explored = 0
    ai_execution_time = 0.0



def next_level():
    global game_state, comparison_results, level_has_solution
    global moves, game_started_at, final_game_time
    global ai_moves, ai_move_index, ai_playing, ai_next_move_time
    global selected_algorithm, ai_was_used
    global ai_nodes_explored, ai_execution_time

    global ai_vs_human_mode, ai_vs_human_turn
    global human_challenge_moves, ai_challenge_moves
    global human_challenge_time, ai_challenge_time
    global challenge_ai_pending, challenge_ai_next_time
    global challenge_winner
    global human_crystals_collected, ai_crystals_collected
    global human_turn_time, human_turn_started_at
    global challenge_ai_nodes, challenge_ai_searches

    # Do not advance if the current level is unfinished.
    if game_state[3] != "won" and level_has_solution:
        return

    # Generate the next level. Do NOT call restart_game(),
    # because it would replace this state with the initial level.
    game_state = generate_new_level()
    level_has_solution = has_solution()

    # Reset normal game statistics.
    moves = 0
    game_started_at = None
    final_game_time = 0.0

    ai_moves = []
    ai_move_index = 0
    ai_playing = False
    ai_next_move_time = 0

    selected_algorithm = "A*"
    ai_was_used = False
    ai_nodes_explored = 0
    ai_execution_time = 0.0

    comparison_results = []

    # Reset challenge statistics.
    challenge_winner = None

    human_challenge_moves = 0
    ai_challenge_moves = 0

    human_challenge_time = 0.0
    ai_challenge_time = 0.0

    human_crystals_collected = 0
    ai_crystals_collected = 0

    human_turn_time = 0.0
    human_turn_started_at = None

    challenge_ai_nodes = 0
    challenge_ai_searches = 0

    challenge_ai_pending = False
    challenge_ai_next_time = 0

    # Start the next level with the AI's turn in challenge mode.
    if ai_vs_human_mode and level_has_solution:
        ai_vs_human_turn = "AI"
        challenge_ai_pending = True
        challenge_ai_next_time = (
            pygame.time.get_ticks() + AI_MOVE_DELAY
        )
    else:
        ai_vs_human_turn = "HUMAN"


# --------------------------------------------------
# HANDLE PLAYER MOVEMENT
# --------------------------------------------------

def handle_move(direction):
    global game_state, moves
    global game_started_at, final_game_time

    if game_state[3] != "playing":
        return

    new_state = move_state(game_state, direction)

    if new_state is not None:
        if game_started_at is None:
            game_started_at = time.perf_counter()

        # Human players need at least one crystal.
        # AI must collect all crystals, so its result
        # must never be overridden by the human rule.
        if not ai_was_used and is_human_goal_state(new_state):
            new_state = (
                new_state[0],
                new_state[1],
                new_state[2],
                "won"
            )

        game_state = new_state
        moves += 1

        if game_state[3] in ("won", "lost"):
            final_game_time = (
                time.perf_counter() - game_started_at
            )


# --------------------------------------------------
# START AI
# --------------------------------------------------

def start_ai(search_name, search_function):
    global ai_playing, ai_moves, ai_move_index
    global ai_next_move_time, selected_algorithm, ai_was_used
    global ai_nodes_explored, ai_execution_time

    restart_game()

    ai_was_used = True
    selected_algorithm = search_name

    start_time = time.perf_counter()
    result = search_function()

    ai_execution_time = (
        time.perf_counter() - start_time
    ) * 1000

    if (
        isinstance(result, tuple)
        and len(result) == 2
        and isinstance(result[1], (int, float))
    ):
        ai_moves, ai_nodes_explored = result
    else:
        ai_moves = result
        ai_nodes_explored = 0

    if ai_moves is None:
        ai_moves = []

    ai_move_index = 0
    ai_playing = bool(ai_moves)
    ai_next_move_time = pygame.time.get_ticks()


# --------------------------------------------------
# UPDATE AI MOVEMENT
# --------------------------------------------------

def update_ai():
    global ai_move_index, ai_playing
    global ai_next_move_time

    if not ai_playing:
        return

    current_time = pygame.time.get_ticks()

    if current_time < ai_next_move_time:
        return

    if ai_move_index >= len(ai_moves):
        ai_playing = False
        return

    handle_move(ai_moves[ai_move_index])
    ai_move_index += 1

    if (
        game_state[3] != "playing"
        or ai_move_index >= len(ai_moves)
    ):
        ai_playing = False
        return

    ai_next_move_time = current_time + AI_MOVE_DELAY


# --------------------------------------------------
# AI VS HUMAN MODE
# --------------------------------------------------

def start_ai_vs_human():
    global ai_vs_human_mode, ai_vs_human_turn
    global human_challenge_moves, ai_challenge_moves
    global human_challenge_time, ai_challenge_time
    global challenge_ai_pending, challenge_ai_next_time
    global game_state, moves, game_started_at, final_game_time
    global ai_playing, ai_was_used, show_comparison
    global comparison_results
    global challenge_winner
    global human_crystals_collected, ai_crystals_collected
    global human_turn_time, human_turn_started_at
    global challenge_ai_nodes, challenge_ai_searches

    restart_game()

    ai_vs_human_mode = True
    ai_vs_human_turn = "HUMAN"

    human_challenge_moves = 0
    ai_challenge_moves = 0

    human_challenge_time = 0.0
    ai_challenge_time = 0.0

    challenge_ai_pending = False
    challenge_ai_next_time = 0

    game_state = create_initial_state()
    moves = 0
    game_started_at = None
    final_game_time = 0.0

    ai_playing = False
    ai_was_used = False

    show_comparison = False
    comparison_results = []

    challenge_winner = None

    human_crystals_collected = 0
    ai_crystals_collected = 0

    human_turn_time = 0.0
    human_turn_started_at = None

    challenge_ai_nodes = 0
    challenge_ai_searches = 0




def update_challenge_ai():
    global ai_vs_human_turn, challenge_ai_pending
    global challenge_ai_next_time
    global ai_challenge_moves, ai_challenge_time
    global game_state, moves, game_started_at, final_game_time
    global ai_crystals_collected, challenge_winner
    global challenge_ai_nodes, challenge_ai_searches

    if not ai_vs_human_mode or not challenge_ai_pending:
        return

    if game_state[3] != "playing":
        challenge_ai_pending = False
        return

    current_time = pygame.time.get_ticks()

    if current_time < challenge_ai_next_time:
        return

    # Recalculate the path from the current shared board.
    search_start = time.perf_counter()
    path, nodes = a_star_search(start_state=game_state)
    search_elapsed = time.perf_counter() - search_start
    challenge_ai_nodes += nodes
    challenge_ai_searches += 1

    # If A* cannot find a winning path, choose a fallback move.
    if not path:
        legal_moves = get_legal_moves(game_state)
        best_move = None
        best_score = float("-inf")

        for direction in legal_moves:
            next_state = move_state(game_state, direction)

            if next_state is None or next_state[3] == "lost":
                continue

            next_player, next_vanished, next_crystals, next_status = next_state

            # Prefer collecting crystals and reaching the exit.
            score = -100 * len(next_crystals)

            if next_status == "won":
                score += 10000
            else:
                if next_crystals:
                    nearest_crystal = min(
                        abs(next_player[0] - crystal[0])
                        + abs(next_player[1] - crystal[1])
                        for crystal in next_crystals
                    )
                    score -= nearest_crystal

                exit_tile = get_exit_tile()
                exit_distance = (
                    abs(next_player[0] - exit_tile[0])
                    + abs(next_player[1] - exit_tile[1])
                )
                score -= exit_distance * 0.1

            if score > best_score:
                best_score = score
                best_move = direction

        if best_move is None:
            # No safe move remains, so the AI loses.
            challenge_ai_pending = False
            game_state = (
                game_state[0],
                game_state[1],
                game_state[2],
                "lost",
            )
            challenge_winner = "HUMAN"

            if game_started_at is not None:
                final_game_time = (
                    time.perf_counter() - game_started_at
                )
            return

        direction = best_move

    else:
        # Use the first move from the newly calculated path.
        direction = path[0]

    # Apply the AI's selected move.
    old_crystals = game_state[2]
    new_state = move_state(game_state, direction)

    if new_state is None:
        return

    # Count crystals collected by the AI.
    new_crystals = new_state[2]
    ai_crystals_collected += (
        len(old_crystals) - len(new_crystals)
    )

    if game_started_at is None:
        game_started_at = time.perf_counter()

    game_state = new_state
    moves += 1
    ai_challenge_moves += 1
    ai_challenge_time += search_elapsed

    challenge_ai_pending = False

    # Record the outcome if the game has ended.
    if game_state[3] in ("won", "lost"):
        if game_state[3] == "won":
            challenge_winner = "AI"
        else:
            challenge_winner = "HUMAN"

        final_game_time = time.perf_counter() - game_started_at
        return

    # AI has moved; now it is the human's turn.
    ai_vs_human_turn = "HUMAN"


def handle_challenge_human_move(direction):
    global ai_vs_human_turn, challenge_ai_pending
    global challenge_ai_next_time
    global human_challenge_moves
    global game_state, moves, game_started_at, final_game_time
    global human_crystals_collected, challenge_winner

    if not ai_vs_human_mode:
        return

    if ai_vs_human_turn != "HUMAN":
        return

    if challenge_ai_pending or game_state[3] != "playing":
        return

    # Save the current crystals before making the move.
    old_crystals = game_state[2]

    new_state = move_state(game_state, direction)

    # Invalid moves do not consume a turn.
    if new_state is None:
        return

    # Count crystals collected by the human.
    new_crystals = new_state[2]
    human_crystals_collected += (
        len(old_crystals) - len(new_crystals)
    )

    if game_started_at is None:
        game_started_at = time.perf_counter()

    game_state = new_state
    moves += 1
    human_challenge_moves += 1

    # Record the outcome if the game has ended.
    if game_state[3] in ("won", "lost"):
        if game_state[3] == "won":
            challenge_winner = "HUMAN"
        else:
            challenge_winner = "AI"

        final_game_time = time.perf_counter() - game_started_at
        challenge_ai_pending = False
        return

    # Schedule the AI's response.
    ai_vs_human_turn = "AI"
    challenge_ai_pending = True
    challenge_ai_next_time = (
        pygame.time.get_ticks() + AI_MOVE_DELAY
    )



# --------------------------------------------------
# DRAW TEXT
# --------------------------------------------------

def draw_text(text, font_used, color, x, y):
    surface = font_used.render(str(text), True, color)
    rect = surface.get_rect(center=(x, y))
    screen.blit(surface, rect)


# --------------------------------------------------
# DRAW GAME BOARD
# --------------------------------------------------

def draw_board(board_x):
    player, vanished_tiles, crystals, status = game_state

    for row in range(ROWS):
        for col in range(COLS):
            x = board_x + col * TILE_SIZE
            y = BOARD_Y + row * TILE_SIZE
            position = (row, col)

            if position in vanished_tiles:
                tile_color = VANISHED_COLOR
            elif position in WALLS:
                tile_color = WALL_COLOR
            else:
                tile_color = TILE_COLOR

            tile_rect = pygame.Rect(
                x, y, TILE_SIZE, TILE_SIZE
            )

            pygame.draw.rect(
                screen, tile_color, tile_rect
            )
            pygame.draw.rect(
                screen, GRID_COLOR, tile_rect, 2
            )

            # Exit
            if position == get_exit_tile() and position not in vanished_tiles:
                pygame.draw.rect(
                    screen,
                    EXIT_COLOR,
                    (
                        x + 8,
                        y + 8,
                        TILE_SIZE - 16,
                        TILE_SIZE - 16,
                    ),
                )

                draw_text(
                    "E",
                    font,
                    WALL_COLOR,
                    x + TILE_SIZE // 2,
                    y + TILE_SIZE // 2,
                )

            # Crystals
            if position in crystals:
                center_x = x + TILE_SIZE // 2
                center_y = y + TILE_SIZE // 2

                points = [
                    (center_x, center_y - 17),
                    (center_x + 13, center_y - 4),
                    (center_x, center_y + 17),
                    (center_x - 13, center_y - 4),
                ]

                pygame.draw.polygon(
                    screen, CRYSTAL_COLOR, points
                )
                pygame.draw.polygon(
                    screen, WHITE, points, 2
                )

            # Player
            if position == player:
                center = (
                    x + TILE_SIZE // 2,
                    y + TILE_SIZE // 2,
                )

                pygame.draw.circle(
                    screen, PLAYER_COLOR, center, 20
                )
                pygame.draw.circle(
                    screen, WHITE, center, 20, 2
                )


# --------------------------------------------------
# GAME TIME
# --------------------------------------------------

def get_elapsed_time():
    if game_started_at is None:
        return 0.0

    if game_state[3] in ("won", "lost"):
        return final_game_time

    return time.perf_counter() - game_started_at


# --------------------------------------------------
# FINAL RESULTS PANEL
# --------------------------------------------------

def draw_results_panel():
    player, vanished_tiles, crystals, status = game_state

    panel_x = 425
    panel_y = 125
    panel_width = 425
    panel_height = 405

    panel_rect = pygame.Rect(
        panel_x,
        panel_y,
        panel_width,
        panel_height,
    )

    pygame.draw.rect(
        screen,
        PANEL_COLOR,
        panel_rect,
        border_radius=10,
    )

    pygame.draw.rect(
        screen,
        PANEL_LINE,
        panel_rect,
        2,
        border_radius=10,
    )

    collected = len(get_start_crystals()) - len(crystals)

    if status == "won":
        if collected == 3:
            outcome = "AI WON!" if ai_was_used else "YOU WON!"
        else:
            outcome = "LEVEL CLEARED"
        outcome_color = PLAYER_COLOR
    else:
        outcome = "LEVEL FAILED"
        outcome_color = RED

    draw_text(
        "FINAL RESULTS",
        font,
        WHITE,
        panel_x + panel_width // 2,
        panel_y + 28,
    )

    draw_text(
        outcome,
        font,
        outcome_color,
        panel_x + panel_width // 2,
        panel_y + 62,
    )

    
    # Draw three achievement stars.
    star_y = panel_y + 92
    star_spacing = 48
    star_center_x = panel_x + panel_width // 2

    gold_color = (255, 200, 45)
    empty_star_color = (100, 105, 120)

    def draw_star(center_x, center_y, color):
        points = []

        for i in range(10):
            angle = -90 + i * 36
            radius = 17 if i % 2 == 0 else 8

            import math

            x = center_x + radius * math.cos(math.radians(angle))
            y = center_y + radius * math.sin(math.radians(angle))

            points.append((int(x), int(y)))

        pygame.draw.polygon(screen, color, points)
        pygame.draw.polygon(screen, WHITE, points, 1)

    for i in range(3):
        star_x = star_center_x + (i - 1) * star_spacing

        if i < collected:
            star_color = gold_color
        else:
            star_color = empty_star_color

        draw_star(star_x, star_y, star_color)


    collected = len(get_start_crystals())-len(crystals)
    rows = [
        ("Player type", "AI" if ai_was_used else "Human"),
        (
            "Outcome",
            "Won" if status == "won" else "Lost",
        ),
        ("Moves made", str(moves)),
        (
            "Elapsed time",
            f"{get_elapsed_time():.2f} seconds",
        ),
        ("Crystals collected", f"{collected}/{len(get_start_crystals())}"),
    ]

    if ai_was_used:
        rows.extend([
            ("Algorithm", selected_algorithm),
            ("Solution length", str(len(ai_moves))),
            (
                "Search time",
                f"{ai_execution_time:.3f} ms",
            ),
            (
                "Nodes explored",
                str(ai_nodes_explored)
                if ai_nodes_explored
                else "Not reported",
            ),
        ])

    table_top = panel_y + 125
    row_height = 29
    label_x = panel_x + 18
    value_x = panel_x + 210

    for index, (label, value) in enumerate(rows):
        row_y = table_top + index * row_height

        if index % 2 == 0:
            row_rect = pygame.Rect(
                panel_x + 10,
                row_y - 12,
                panel_width - 20,
                row_height,
            )

            pygame.draw.rect(
                screen,
                (43, 51, 71),
                row_rect,
                border_radius=4,
            )

        label_surface = tiny_font.render(
            label, True, MUTED_TEXT
        )

        value_surface = tiny_font.render(
            value, True, WHITE
        )

        screen.blit(
            label_surface, (label_x, row_y - 8)
        )
        screen.blit(
            value_surface, (value_x, row_y - 8)
        )



def draw_challenge_results_panel():
    panel_x = 425
    panel_y = 125
    panel_width = 425
    panel_height = 405

    panel_rect = pygame.Rect(
        panel_x,
        panel_y,
        panel_width,
        panel_height,
    )

    pygame.draw.rect(
        screen,
        PANEL_COLOR,
        panel_rect,
        border_radius=12,
    )
    pygame.draw.rect(
        screen,
        PANEL_LINE,
        panel_rect,
        2,
        border_radius=12,
    )

    # Winner heading
    if challenge_winner == "HUMAN":
        heading = "HUMAN WINS!"
        heading_color = PLAYER_COLOR
    elif challenge_winner == "AI":
        heading = "AI WINS!"
        heading_color = CRYSTAL_COLOR
    else:
        heading = "CHALLENGE OVER"
        heading_color = WHITE

    draw_text(
        "AI VS HUMAN RESULTS",
        font,
        WHITE,
        panel_x + panel_width // 2,
        panel_y + 30,
    )

    draw_text(
        heading,
        title_font,
        heading_color,
        panel_x + panel_width // 2,
        panel_y + 70,
    )

    pygame.draw.line(
        screen,
        PANEL_LINE,
        (panel_x + 20, panel_y + 100),
        (panel_x + panel_width - 20, panel_y + 100),
        2,
    )

    # Column headings
    draw_text(
        "HUMAN",
        font,
        PLAYER_COLOR,
        panel_x + 115,
        panel_y + 128,
    )

    draw_text(
        "AI (A*)",
        font,
        CRYSTAL_COLOR,
        panel_x + 315,
        panel_y + 128,
    )

    # Moves
    draw_text(
        "Moves",
        small_font,
        WHITE,
        panel_x + 45,
        panel_y + 165,
    )
    draw_text(
        str(human_challenge_moves),
        small_font,
        WHITE,
        panel_x + 115,
        panel_y + 165,
    )
    draw_text(
        str(ai_challenge_moves),
        small_font,
        WHITE,
        panel_x + 315,
        panel_y + 165,
    )

    # Crystals collected
    draw_text(
        "Crystals",
        small_font,
        WHITE,
        panel_x + 45,
        panel_y + 200,
    )
    draw_text(
        f"{human_crystals_collected}/3",
        small_font,
        WHITE,
        panel_x + 115,
        panel_y + 200,
    )
    draw_text(
        f"{ai_crystals_collected}/3",
        small_font,
        WHITE,
        panel_x + 315,
        panel_y + 200,
    )

    pygame.draw.line(
        screen,
        PANEL_LINE,
        (panel_x + 20, panel_y + 225),
        (panel_x + panel_width - 20, panel_y + 225),
        1,
    )

    # AI search statistics
    draw_text(
        f"AI searches: {challenge_ai_searches}",
        small_font,
        WHITE,
        panel_x + panel_width // 2,
        panel_y + 255,
    )

    draw_text(
        f"Total nodes explored: {challenge_ai_nodes}",
        small_font,
        WHITE,
        panel_x + panel_width // 2,
        panel_y + 285,
    )

    draw_text(
        f"AI search time: {ai_challenge_time:.3f} sec",
        small_font,
        WHITE,
        panel_x + panel_width // 2,
        panel_y + 315,
    )

    draw_text(
        f"Total game time: {final_game_time:.2f} sec",
        small_font,
        WHITE,
        panel_x + panel_width // 2,
        panel_y + 345,
    )

    draw_text(
        "R: Retry | N: Next Level | Q: Quit Challenge",
        small_font,
        WHITE,
        panel_x + panel_width // 2,
        panel_y + 380,
    )


def draw_challenge_warning():
    # Dim the game screen behind the popup.
    overlay = pygame.Surface((WIDTH, HEIGHT))
    overlay.set_alpha(190)
    overlay.fill((0, 0, 0))
    screen.blit(overlay, (0, 0))

    pygame.draw.rect(
        screen, PANEL_COLOR, WARNING_RECT, border_radius=12
    )
    pygame.draw.rect(
        screen, PANEL_LINE, WARNING_RECT, 2, border_radius=12
    )

    draw_text(
        "AI VS HUMAN MODE",
        font, CRYSTAL_COLOR,
        WIDTH // 2, 205
    )

    draw_text(
        "Collect ALL 3 crystals and reach the exit",
        small_font, WHITE,
        WIDTH // 2, 245
    )

    draw_text(
        "to clear the level. This rule applies to both.",
        small_font, WHITE,
        WIDTH // 2, 272
    )

    mouse_position = pygame.mouse.get_pos()
    button_color = (
        BUTTON_HOVER_COLOR
        if WARNING_CLOSE_BUTTON.collidepoint(mouse_position)
        else BUTTON_COLOR
    )

    pygame.draw.rect(
        screen, button_color,
        WARNING_CLOSE_BUTTON, border_radius=8
    )

    draw_text(
        "CLOSE", font, WHITE,
        WARNING_CLOSE_BUTTON.centerx,
        WARNING_CLOSE_BUTTON.centery
    )


# --------------------------------------------------
# DRAW MAIN GAME SCREEN
# --------------------------------------------------

def draw_screen():
    screen.fill(BACKGROUND)

    player, vanished_tiles, crystals, status = game_state
    game_over = status in ("won", "lost")

    draw_text(
        "VANISHING WORLD",
        title_font,
        WHITE,
        WIDTH // 2,
        32,
    )

    draw_text(
        "Collect all crystals and reach the exit",
        small_font,
        WHITE,
        WIDTH // 2,
        68,
    )

    draw_text(
        f"LEVEL {get_level_number()}",
        font,
        EXIT_COLOR,
        WIDTH // 2,
        98,
    )

    board_x = 55 if game_over or not level_has_solution else (
        WIDTH - BOARD_WIDTH
    ) // 2

    draw_board(board_x)

    board_center = board_x + BOARD_WIDTH // 2

    draw_text(
        f"Moves: {moves}",
        font,
        WHITE,
        board_center - 70,
        465,
    )

    draw_text(
        f"Crystals left: {len(crystals)}",
        font,
        CRYSTAL_COLOR,
        board_center + 75,
        465,
    )

    # LEVEL HAS NO SOLUTION
    if not level_has_solution:
        draw_text(
            "NO SOLUTION",
            title_font,
            RED,
            WIDTH // 2,
            490,
        )

        draw_text(
            "This level cannot be completed.",
            small_font,
            WHITE,
            WIDTH // 2,
            520,
        )

        draw_text(
            "Press N to generate the next level",
            font,
            EXIT_COLOR,
            WIDTH // 2,
            560,
        )
        return

    # LEVEL CLEARED
    if status == "won":
        if ai_vs_human_mode:
            draw_challenge_results_panel()
        else:
            draw_results_panel()

        draw_text(
            "LEVEL CLEARED!",
            font,
            PLAYER_COLOR,
            WIDTH // 2,
            555,
        )

        draw_text(
            "N: Next Level | R: Restart | C: Compare Algorithms",
            small_font,
            WHITE,
            WIDTH // 2,
            580,
        )

    # LEVEL FAILED
    elif status == "lost":
        if ai_vs_human_mode:
            draw_challenge_results_panel()
        else:
            draw_results_panel()

        draw_text(
            "LEVEL FAILED!",
            font,
            RED,
            WIDTH // 2,
            555,
        )

        draw_text(
            "Press R to Retry This Level",
            small_font,
            WHITE,
            WIDTH // 2,
            580,
        )

    # AI PLAYBACK
    elif ai_playing and not ai_vs_human_mode:
        draw_text(
            "AI is playing...",
            small_font,
            CRYSTAL_COLOR,
            WIDTH // 2,
            510,
        )

    # GAMEPLAY INSTRUCTIONS
    if status == "playing":
        if ai_vs_human_mode:
            if challenge_ai_pending or ai_vs_human_turn == "AI":
                turn_message = "AI is thinking..."
                turn_color = CRYSTAL_COLOR
            else:
                turn_message = "YOUR TURN"
                turn_color = PLAYER_COLOR

            draw_text(
                turn_message,
                font,
                turn_color,
                WIDTH // 2,
                500,
            )

            draw_text(
                "Q: Quit AI vs Human",
                small_font,
                WHITE,
                WIDTH // 2,
                535,
            )

        elif ai_playing:
            draw_text(
                "AI is playing...",
                small_font,
                CRYSTAL_COLOR,
                WIDTH // 2,
                510,
            )

        else:
            draw_text(
                "Select AI: 1 BFS | 2 DFS | 3 IDDFS | 4 Greedy | 5 A*",
                small_font,
                WHITE,
                WIDTH // 2,
                510,
            )

            draw_text(
                "Arrows: Move | R: Restart | V: AI vs Human",
                small_font,
                WHITE,
                WIDTH // 2,
                535,
            )



# --------------------------------------------------
# CALCULATE COMPARISON RESULTS
# --------------------------------------------------

def load_comparison_results():
    global comparison_results

    if comparison_results:
        return

    comparison_results = compare_algorithms()

    if comparison_results is None:
        comparison_results = []


# --------------------------------------------------
# DRAW ALGORITHM COMPARISON SCREEN
# --------------------------------------------------

def draw_comparison_screen():
    screen.fill((20, 25, 40))

    # ------------------------------
    # Title
    # ------------------------------
    draw_text(
        "AI ALGORITHM COMPARISON",
        title_font,
        WHITE,
        WIDTH // 2,
        35,
    )

    if not comparison_results:
        draw_text(
            "No comparison results available.",
            font,
            RED,
            WIDTH // 2,
            180,
        )
        draw_text(
            "Press C to return to the game",
            small_font,
            (255, 220, 100),
            WIDTH // 2,
            565,
        )
        return

    successful = [
        r for r in comparison_results
        if r["moves"] is not None
    ]

    shortest_moves = (
        min(r["moves"] for r in successful)
        if successful else None
    )

    fewest_nodes = min(
        r["nodes"] for r in comparison_results
    )

    fastest_time = min(
        r["time"] for r in comparison_results
    )

    # ------------------------------
    # Comparison table
    # ------------------------------
    table_left = 65
    table_top = 85
    row_height = 35

    columns = [
        ("Algorithm", 145),
        ("Moves", 430),
        ("Nodes", 565),
        ("Time (ms)", 735),
    ]

    for heading, x in columns:
        draw_text(
            heading,
            font,
            CRYSTAL_COLOR,
            x,
            table_top,
        )

    for index, result in enumerate(comparison_results):
        y = table_top + 40 + index * row_height

        is_shortest = (
            result["moves"] is not None
            and result["moves"] == shortest_moves
        )

        is_fewest_nodes = result["nodes"] == fewest_nodes
        is_fastest = result["time"] == fastest_time

        name_color = (
            (120, 235, 160)
            if is_shortest else WHITE
        )

        draw_text(
            result["name"],
            small_font,
            name_color,
            columns[0][1],
            y,
        )

        moves_text = (
            str(result["moves"])
            if result["moves"] is not None
            else "N/A"
        )

        draw_text(
            moves_text,
            small_font,
            name_color,
            columns[1][1],
            y,
        )

        nodes_color = (
            (120, 235, 160)
            if is_fewest_nodes else WHITE
        )

        draw_text(
            result["nodes"],
            small_font,
            nodes_color,
            columns[2][1],
            y,
        )

        time_color = (
            (120, 235, 160)
            if is_fastest else WHITE
        )

        draw_text(
            f'{result["time"]:.2f}',
            small_font,
            time_color,
            columns[3][1],
            y,
        )

    # ------------------------------
    # Legend
    # ------------------------------
    legend_y = 280

    draw_text(
        "Green: best result in that category",
        tiny_font,
        (120, 235, 160),
        WIDTH // 2,
        legend_y,
    )

    # ------------------------------
    # Nodes explored bar chart
    # ------------------------------
    draw_text(
        "NODES EXPLORED",
        font,
        CRYSTAL_COLOR,
        WIDTH // 2,
        315,
    )

    chart_x = 285
    chart_y = 345
    chart_width = 480
    bar_height = 20
    bar_gap = 9

    max_nodes = max(
        max(r["nodes"] for r in comparison_results),
        1,
    )

    for index, result in enumerate(comparison_results):
        y = chart_y + index * (bar_height + bar_gap)

        draw_text(
            result["name"],
            tiny_font,
            WHITE,
            190,
            y + bar_height // 2,
        )

        bar_width = int(
            result["nodes"] / max_nodes * chart_width
        )

        if result["nodes"] > 0:
            bar_width = max(bar_width, 2)

        bar_color = (
            (120, 235, 160)
            if result["nodes"] == fewest_nodes
            else CRYSTAL_COLOR
        )

        pygame.draw.rect(
            screen,
            bar_color,
            (chart_x, y, bar_width, bar_height),
            border_radius=3,
        )

        # Keep the node count inside the screen.
        value_x = min(
            chart_x + bar_width + 35,
            WIDTH - 35,
        )

        draw_text(
            result["nodes"],
            tiny_font,
            WHITE,
            value_x,
            y + bar_height // 2,
        )

    # ------------------------------
    # Summary
    # ------------------------------
    summary_y = 500

    if successful:
        shortest_names = [
            r["name"] for r in successful
            if r["moves"] == shortest_moves
        ]

        draw_text(
            f"Shortest solution: {shortest_moves} moves "
            f"({', '.join(shortest_names)})",
            small_font,
            (120, 235, 160),
            WIDTH // 2,
            summary_y,
        )

    fewest_names = [
        r["name"] for r in comparison_results
        if r["nodes"] == fewest_nodes
    ]

    fastest_names = [
        r["name"] for r in comparison_results
        if r["time"] == fastest_time
    ]

    draw_text(
        f"Fewest nodes: {', '.join(fewest_names)}",
        tiny_font,
        WHITE,
        WIDTH // 2,
        summary_y + 22,
    )

    draw_text(
        f"Fastest: {', '.join(fastest_names)}",
        tiny_font,
        WHITE,
        WIDTH // 2,
        summary_y + 41,
    )

    draw_text(
        "Press C to return to the game",
        small_font,
        (255, 220, 100),
        WIDTH // 2,
        580,
    )


def draw_instructions():
    """Display the scrollable game instructions."""

    screen.fill(BACKGROUND)

    draw_text(
        "VANISHING WORLD",
        title_font,
        CRYSTAL_COLOR,
        WIDTH // 2,
        35
    )

    draw_text(
        "HOW TO PLAY",
        font,
        WHITE,
        WIDTH // 2,
        75
    )

    # The instruction content is displayed inside this area.
    content_area = pygame.Rect(35, 105, WIDTH - 70, 345)

    # Prevent text from appearing outside the content area.
    screen.set_clip(content_area)

    instructions = [
        ("OBJECTIVE", [
            "Human: collect at least 1 crystal and reach the exit.",
            "AI: collect all 3 crystals and reach the exit."
        ]),
        ("MOVEMENT", [
            "Use the arrow keys to move one tile at a time.",
            "You can move up, down, left, or right."
        ]),
        ("VANISHING TILES", [
            "Every tile you leave disappears permanently.",
            "You cannot enter a vanished tile again.",
            "Plan your route carefully to avoid getting trapped."
        ]),
        ("CRYSTALS", [
            "Collect crystals by moving onto their tiles.",
            "Human players need at least 1 crystal to win.",
            "AI algorithms must collect all 3 crystals."
        ]),
        ("WALLS AND BOUNDARIES", [
            "Walls and board edges block your movement.",
            "Choose another route when a path is blocked."
        ]),
        ("WINNING AND LOSING", [
            "WIN: Collect all crystals and reach the exit.",
            "LOSE: No legal moves remain before you win."
        ]),
        ("AI CONTROLS", [
            "1 - Breadth-First Search (BFS)",
            "2 - Depth-First Search (DFS)",
            "3 - Iterative Deepening DFS (IDDFS)",
            "4 - Greedy Best-First Search",
            "5 - A* Search",
            "The AI searches for a solution and plays it."
        ]),
        ("OTHER CONTROLS", [
            "R - Restart the current game.",
            "C - Open the algorithm comparison screen.",
            "N - Generate a next level, if enabled."
        ])
    ]

    y = 115 - instruction_scroll

    for heading, lines in instructions:

        draw_text(
            heading,
            font,
            EXIT_COLOR,
            WIDTH // 2,
            y
        )
        y += 28

        for line in lines:
            draw_text(
                line,
                small_font,
                WHITE,
                WIDTH // 2,
                y
            )
            y += 24

        y += 12

    screen.set_clip(None)

    # Show a small scrolling hint.
    draw_text(
        "Scroll with your mouse wheel or use Up/Down arrows",
        small_font,
        CRYSTAL_COLOR,
        WIDTH // 2,
        460
    )

    # Keep the Close button at the bottom of the window.
    mouse_position = pygame.mouse.get_pos()

    if CLOSE_BUTTON.collidepoint(mouse_position):
        button_color = BUTTON_HOVER_COLOR
    else:
        button_color = BUTTON_COLOR

    pygame.draw.rect(
        screen,
        button_color,
        CLOSE_BUTTON,
        border_radius=8
    )

    draw_text(
        "CLOSE",
        font,
        WHITE,
        CLOSE_BUTTON.centerx,
        CLOSE_BUTTON.centery
    )

    pygame.display.update()


def handle_instruction_scroll(event):
    """Handle scrolling and closing the instruction page."""

    global instructions_open, instruction_scroll

    if event.type == pygame.MOUSEWHEEL:
        instruction_scroll -= event.y * 25

    elif event.type == pygame.KEYDOWN:

        if event.key == pygame.K_DOWN:
            instruction_scroll += 25

        elif event.key == pygame.K_UP:
            instruction_scroll -= 25

        elif event.key == pygame.K_PAGEDOWN:
            instruction_scroll += 150

        elif event.key == pygame.K_PAGEUP:
            instruction_scroll -= 150

        elif event.key == pygame.K_ESCAPE:
            instructions_open = False

    elif event.type == pygame.MOUSEBUTTONDOWN:

        if event.button == 1:
            if CLOSE_BUTTON.collidepoint(event.pos):
                instructions_open = False

    # Keep the scroll position within sensible limits.
    instruction_scroll = max(0, min(instruction_scroll, 350))



# --------------------------------------------------
# MAIN GAME LOOP
# --------------------------------------------------
def main():
    global show_comparison, instructions_open
    global challenge_warning_open, ai_vs_human_mode
    global challenge_ai_pending, ai_vs_human_turn

    running = True

    while running:
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                running = False

            elif instructions_open:
                handle_instruction_scroll(event)

            elif challenge_warning_open:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        challenge_warning_open = False

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if (
                        event.button == 1
                        and WARNING_CLOSE_BUTTON.collidepoint(event.pos)
                    ):
                        challenge_warning_open = False

            elif event.type == pygame.KEYDOWN:
                # Enter AI vs Human mode.
                if event.key == pygame.K_v and not ai_vs_human_mode:
                    start_ai_vs_human()
                    challenge_warning_open = True
                    continue

                # Quit AI vs Human mode.
                if event.key == pygame.K_q and ai_vs_human_mode:
                    ai_vs_human_mode = False
                    challenge_warning_open = False
                    challenge_ai_pending = False
                    ai_vs_human_turn = "HUMAN"
                    restart_game()
                    continue

                # No-solution state:
                # only N is allowed, apart from quitting.
                if not level_has_solution:
                    if event.key == pygame.K_n:
                        show_comparison = False
                        next_level()

                    continue

                # Restart or retry the current level.
                if event.key == pygame.K_r:
                    show_comparison = False
                    restart_game()

                # Next level is allowed only after winning.
                
                elif event.key == pygame.K_n:
                    if game_state[3] == "won" or not level_has_solution:
                        show_comparison = False
                        next_level()


                # Comparison screen.
                
                elif event.key == pygame.K_c:
                    if game_state[3] == "won":
                        show_comparison = not show_comparison

                        if show_comparison:
                            load_comparison_results()

                # AI algorithms only during active gameplay.
                elif game_state[3] == "playing" and not show_comparison:

                    if event.key == pygame.K_1:
                        start_ai("BFS", bfs_search)

                    elif event.key == pygame.K_2:
                        start_ai("DFS", dfs_search)

                    elif event.key == pygame.K_3:
                        start_ai("IDDFS", iddfs_search)

                    elif event.key == pygame.K_4:
                        start_ai("Greedy", greedy_search)

                    elif event.key == pygame.K_5:
                        start_ai("A*", a_star_search)

                    elif not ai_playing:

                        if event.key == pygame.K_UP:
                            if ai_vs_human_mode:
                                handle_challenge_human_move("UP")
                            else:
                                handle_move("UP")

                        elif event.key == pygame.K_DOWN:
                            if ai_vs_human_mode:
                                handle_challenge_human_move("DOWN")
                            else:
                                handle_move("DOWN")

                        elif event.key == pygame.K_LEFT:
                            if ai_vs_human_mode:
                                handle_challenge_human_move("LEFT")
                            else:
                                handle_move("LEFT")

                        elif event.key == pygame.K_RIGHT:
                            if ai_vs_human_mode:
                                handle_challenge_human_move("RIGHT")
                            else:
                                handle_move("RIGHT")

        # Update AI only during active gameplay.
        if (
            not instructions_open
            and not challenge_warning_open
            and not show_comparison
            and level_has_solution
            and game_state[3] == "playing"
        ):
            if ai_vs_human_mode:
                update_challenge_ai()
            else:
                update_ai()

        # Draw the appropriate screen.
        if instructions_open:
            draw_instructions()

        elif challenge_warning_open:
            draw_screen()
            draw_challenge_warning()

        elif show_comparison:
            draw_comparison_screen()

        else:
            draw_screen()

        pygame.display.flip()
        clock.tick(30)

    pygame.quit()

# --------------------------------------------------
# RUN GAME
# --------------------------------------------------

if __name__ == "__main__":
    main()
