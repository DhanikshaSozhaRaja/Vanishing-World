
# compare_algorithms.py

import time

from ai_search import (
    bfs_search,
    dfs_search,
    iddfs_search,
    greedy_search,
    a_star_search
)


def compare_algorithms():

    algorithms = [
        ("BFS", bfs_search),
        ("DFS", dfs_search),
        ("IDDFS", iddfs_search),
        ("Greedy Best-First", greedy_search),
        ("A*", a_star_search)
    ]

    results = []

    print("\nVANISHING WORLD - AI ALGORITHM COMPARISON")
    print("=" * 75)

    for name, algorithm in algorithms:

        print("\nRunning", name, "...")

        start_time = time.perf_counter()

        solution, nodes_explored = algorithm()

        end_time = time.perf_counter()

        execution_time = (end_time - start_time) * 1000

        if solution is None:
            moves = None
            path = "No solution found"
        else:
            moves = len(solution)
            path = " -> ".join(solution)

        results.append({
            "name": name,
            "moves": moves,
            "nodes": nodes_explored,
            "time": execution_time,
            "path": path
        })

    # Display comparison table
    print("\n\nFINAL RESULTS")
    print("=" * 75)

    print(
        f"{'Algorithm':<20}"
        f"{'Moves':<12}"
        f"{'Nodes Explored':<20}"
        f"{'Time (ms)':<15}"
    )

    print("-" * 67)

    for result in results:

        moves = (
            str(result["moves"])
            if result["moves"] is not None
            else "No solution"
        )

        print(
            f"{result['name']:<20}"
            f"{moves:<12}"
            f"{result['nodes']:<20}"
            f"{result['time']:<15.3f}"
        )

    # Find the shortest successful solution
    successful_results = [
        result for result in results
        if result["moves"] is not None
    ]

    print("\nSHORTEST SOLUTION")
    print("=" * 40)

    if successful_results:

        shortest = min(
            successful_results,
            key=lambda result: result["moves"]
        )

        print("Algorithm:", shortest["name"])
        print("Number of moves:", shortest["moves"])
        print("Solution path:", shortest["path"])

        shortest_algorithms = [
            result["name"]
            for result in successful_results
            if result["moves"] == shortest["moves"]
        ]

        print(
            "Algorithms with the shortest solution:",
            ", ".join(shortest_algorithms)
        )

    else:
        print("None of the algorithms found a solution.")

    # Display each solution path
    print("\nSOLUTION PATHS")
    print("=" * 75)

    for result in results:

        print("\n" + result["name"] + ":")

        if result["moves"] is None:
            print("No solution found.")
        else:
            print("Moves:", result["path"])

    print("\nComparison completed.")
    
    return results


if __name__ == "__main__":
    compare_algorithms()
